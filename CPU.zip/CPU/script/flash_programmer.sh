#!/bin/sh
#
# This file was automatically generated.
#
# It can be overwritten by nios2-flash-programmer-generate or nios2-flash-programmer-gui.
#

#
# Converting ELF File: C:\U3\2023FPGA\CPU\software\Hello_NiosII\Hello_NiosII.elf to: "..\flash/Hello_NiosII_cfi_flash.flash"
#
elf2flash --input="C:/U3/2023FPGA/CPU/software/Hello_NiosII/Hello_NiosII.elf" --output="../flash/Hello_NiosII_cfi_flash.flash" --boot="$SOPC_KIT_NIOS2/components/altera_nios2/boot_loader_cfi.srec" --base=0x800000 --end=0x1000000 --reset=0x800000 --verbose 

#
# Programming File: "..\flash/Hello_NiosII_cfi_flash.flash" To Device: cfi_flash
#
nios2-flash-programmer "../flash/Hello_NiosII_cfi_flash.flash" --base=0x800000 --sidp=0x1081010 --id=0x0 --timestamp=1680175434 --device=1 --instance=0 '--cable=USB-Blaster on localhost [USB-0]' --program --verbose 


#include "alt_types.h"
#include <stdio.h>
#include <unistd.h>
#include "system.h"
#include "sys/alt_irq.h"
#include "altera_avalon_pio_regs.h"

static alt_u8 count1;
static alt_u8 count2;
static alt_u8 count3;
static alt_u8 count4;
volatile int edge_capture;

#ifdef BUTTON_PIO_BASE
#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
static void handle_button_interrupts(void* context)
#else
	static void handle_button_interrupts(void* context, alt_u32 id)
#endif
{

	/* Cast context to edge_capture��s type. It is important that this be
	* declared volatile to avoid unwanted compiler
	*/

	volatile int* edge_capture_ptr = (volatile int*)context;

	// Store the value in the Button��s edge capture register in *context.
	*edge_capture_ptr =
	IORD_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_PIO_BASE);

	// Reset the Button��s edge capture register.
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_PIO_BASE, 0);

	/*
	* Read the PIO to delay ISR exit. This is done to prevent a spurious
	* interrupt in systems with high processor --> pio latency and fast
	*/

	IORD_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_PIO_BASE);
}

// Initialize the button_pio.
static void init_button_pio(){
	/* Recast the edge_capture pointer to match the alt_irq_register() function
	* prototype. */
	void* edge_capture_ptr = (void*)&edge_capture;

	// Enable all 4 button interrupts.
	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(BUTTON_PIO_BASE, 0xf);

	// Reset the edge capture register.
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_PIO_BASE, 0x0);

	// Register the interrupt handler.
	#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
		alt_ic_isr_register(BUTTON_PIO_IRQ_INTERRUPT_CONTROLLER_ID,
		BUTTON_PIO_IRQ,
		handle_button_interrupts, edge_capture_ptr, 0x0);
	#else
		alt_irq_register(BUTTON_PIO_IRQ, edge_capture_ptr,
		handle_button_interrupts);
	#endif
}

#endif // BUTTON_PIO_BASE

static void count_led(int hex){
	#ifdef LED_PIO_BASE
		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_BASE, hex);
	#endif
}

static void handle_button_press( ){
	// Button press actions while counting.
	switch(edge_capture){
		// Button 1: Output count1 to LED.
		case 0x1:
			count_led(count1);
			break;
		// Button 2: Output count2 to LED.
		case 0x2:
			count_led(count2);
			break;
		// Button 3: Output count3 to LED.
		case 0x4:
			count_led(count3);
			break;
		// Button 4: Output counting to LED.
		case 0x8:
			count_led(count4);
			break;
		// If value ends up being something different (shouldn��t) do same as 8.
		default:
			count_led(8);;
			break;
	}
}

int main(void){
	count1 = 15;
	count2 = 0;
	count3 = 8;
	count4 = 5;

	// Initialize the button pio.
	#ifdef BUTTON_PIO_BASE
		init_button_pio();
	#endif
	printf("\nWelcome...\n");
	while(1){
		usleep(100000);
		count1 = count1 - 1;
		++count2;
		++count3;
		count4 = count4 - 1;
		if(edge_capture != 0) handle_button_press(); // Handle button presses while counting...
		else count_led(7);
		if(count1 == 0) edge_capture = 0;
	}
}


